/**
 * PowerMenuNative.ts
 *
 * Interface TypeScript para o módulo nativo Android PowerMenuModule.
 * Fornece tipagem segura para as funções expostas pelo código Java.
 */

import { NativeModules, Platform } from 'react-native';

const { PowerMenuModule } = NativeModules;

/**
 * Verifica se o dispositivo é Android.
 * As funções deste módulo só funcionam no Android.
 */
const isAndroid = Platform.OS === 'android';

/**
 * Verifica se o AccessibilityService está habilitado nas configurações do dispositivo.
 * @returns Promise<boolean> — true se o serviço estiver ativo
 */
export async function isAccessibilityEnabled(): Promise<boolean> {
  if (!isAndroid || !PowerMenuModule) return false;
  return PowerMenuModule.isAccessibilityEnabled();
}

/**
 * Abre a tela de configurações de acessibilidade do Android.
 * O usuário deve habilitar o "Power Menu App" manualmente.
 */
export async function openAccessibilitySettings(): Promise<void> {
  if (!isAndroid || !PowerMenuModule) return;
  return PowerMenuModule.openAccessibilitySettings();
}

/**
 * Aciona o menu de energia do Android via AccessibilityService.
 * Lança um erro se o serviço não estiver ativo.
 */
export async function triggerPowerMenu(): Promise<void> {
  if (!isAndroid || !PowerMenuModule) {
    throw new Error('Esta função está disponível apenas no Android.');
  }
  return PowerMenuModule.triggerPowerMenu();
}
