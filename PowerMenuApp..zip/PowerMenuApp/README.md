# Power Menu App (React Native / Expo)

Aplicativo Android desenvolvido em React Native (bare workflow) com Módulo Nativo que utiliza um `AccessibilityService` para acionar o Menu de Energia do dispositivo através do comando `GLOBAL_ACTION_POWER_DIALOG`. O aplicativo é totalmente em português.

## 🚀 Estrutura do Projeto

O projeto está estruturado em um ambiente **Expo Bare Workflow** para permitir o desenvolvimento em React Native mantendo o controle total sobre o código nativo Android.

### Principais Componentes

*   **`App.tsx`**: Tela principal do aplicativo com o botão centralizado e verificação de permissões.
*   **`src/PowerMenuNative.ts`**: Interface TypeScript para comunicação com o módulo nativo Android.
*   **`android/app/src/main/java/com/powermenuapp/PowerMenuModule.java`**: Módulo nativo que expõe as funções para o JavaScript (verificar permissão, abrir configurações, acionar menu).
*   **`android/app/src/main/java/com/powermenuapp/PowerMenuAccessibilityService.java`**: Serviço de Acessibilidade nativo que executa a ação global `GLOBAL_ACTION_POWER_DIALOG`.
*   **`android/app/src/main/AndroidManifest.xml`**: Declaração das permissões e registro do serviço de acessibilidade.
*   **`android/app/src/main/res/xml/accessibility_service_config.xml`**: Configuração XML do serviço de acessibilidade.
*   **`eas.json`**: Configurações de build para o Expo Application Services (EAS).

## 🛠️ Como Funciona

O aplicativo precisa de permissões especiais de acessibilidade para poder abrir o menu de energia do sistema operacional. O fluxo é o seguinte:

1.  Ao iniciar, o aplicativo verifica se o serviço de acessibilidade "Power Menu App" está ativado nas configurações do Android.
2.  Se não estiver ativado, uma tela de aviso é exibida, solicitando que o usuário ative a permissão e fornecendo um botão para abrir diretamente as configurações de acessibilidade do dispositivo.
3.  Após a permissão ser concedida, a tela principal é exibida com um botão centralizado "Abrir Menu de Energia".
4.  Ao clicar no botão, o código JavaScript chama o módulo nativo, que por sua vez utiliza a instância ativa do `PowerMenuAccessibilityService` para executar a ação `performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)`.

## 📦 Compilando com o EAS (Expo Application Services)

Como o aplicativo utiliza código nativo personalizado (o `AccessibilityService`), **ele não funcionará no aplicativo Expo Go padrão**. Você precisará compilar o aplicativo (gerar um APK ou App Bundle) para testá-lo em um dispositivo real ou emulador.

A configuração do EAS já está pronta no arquivo `eas.json`. Siga os passos abaixo para compilar o projeto:

### Pré-requisitos

1.  Ter uma conta no [Expo](https://expo.dev/).
2.  Ter a CLI do EAS instalada globalmente:
    ```bash
    npm install -g eas-cli
    ```
3.  Estar autenticado na CLI do EAS:
    ```bash
    eas login
    ```

### Passo a Passo para Gerar o APK

1.  **Inicialize o projeto no EAS** (se ainda não o fez):
    ```bash
    eas init --id SEU_PROJECT_ID_AQUI
    ```
    *Nota: Lembre-se de atualizar o `projectId` no arquivo `app.json` com o ID gerado pelo comando acima.*

2.  **Execute o comando de build para gerar um APK de desenvolvimento (Preview)**:
    ```bash
    eas build --platform android --profile preview
    ```
    *Este comando usará o perfil `preview` definido no `eas.json`, que está configurado para gerar um arquivo `.apk` (`buildType: "apk"`).*

3.  **Aguarde a compilação**: O EAS irá processar a compilação nos servidores do Expo. O processo pode levar alguns minutos.

4.  **Baixe e instale**: Ao final, a CLI do EAS fornecerá um link para download do APK. Baixe o arquivo, envie para o seu dispositivo Android e instale.

### Compilando Localmente (Opcional)

Se preferir compilar localmente na sua máquina (sem usar o EAS), você pode usar o comando padrão do React Native/Android Studio:

```bash
npm install
npx react-native run-android
```
*(Certifique-se de ter o ambiente de desenvolvimento Android configurado na sua máquina: Android Studio, SDK, variáveis de ambiente).*

## ⚠️ Observações Importantes

*   **Permissão de Acessibilidade**: O Android é rigoroso com serviços de acessibilidade. O usuário deve **sempre** ativar a permissão manualmente nas configurações do sistema. O aplicativo facilita isso abrindo a tela de configurações correta.
*   **Nenhum dado é coletado**: A configuração `accessibilityEventTypes=""` no arquivo `accessibility_service_config.xml` garante que o serviço não intercepte nenhum evento da tela do usuário, garantindo a privacidade. Ele apenas utiliza a capacidade de executar ações globais.
