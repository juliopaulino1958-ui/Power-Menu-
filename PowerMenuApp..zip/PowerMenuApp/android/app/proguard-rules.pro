# Regras ProGuard para o Power Menu App

# Mantém o AccessibilityService (necessário para que o Android possa instanciá-lo)
-keep class com.powermenuapp.PowerMenuAccessibilityService { *; }

# Mantém o módulo nativo (necessário para o React Native)
-keep class com.powermenuapp.PowerMenuModule { *; }
-keep class com.powermenuapp.PowerMenuPackage { *; }

# React Native
-keep class com.facebook.react.** { *; }
-keep class com.facebook.hermes.** { *; }
-keep class com.facebook.jni.** { *; }

# AndroidX
-keep class androidx.** { *; }
