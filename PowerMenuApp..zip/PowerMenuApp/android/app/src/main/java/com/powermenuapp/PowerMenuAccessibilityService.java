package com.powermenuapp;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.util.Log;

/**
 * PowerMenuAccessibilityService
 *
 * Serviço de acessibilidade responsável por executar a ação global
 * GLOBAL_ACTION_POWER_DIALOG, que abre o menu de energia do Android.
 *
 * Este serviço precisa ser habilitado manualmente pelo usuário em:
 * Configurações > Acessibilidade > Power Menu App
 */
public class PowerMenuAccessibilityService extends AccessibilityService {

    private static final String TAG = "PowerMenuService";

    // Instância estática para acesso a partir do módulo nativo
    private static PowerMenuAccessibilityService instance;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        Log.d(TAG, "Serviço de acessibilidade conectado.");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Não precisamos processar eventos de acessibilidade neste serviço
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "Serviço de acessibilidade interrompido.");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        Log.d(TAG, "Serviço de acessibilidade destruído.");
    }

    /**
     * Retorna a instância ativa do serviço, ou null se não estiver ativo.
     */
    public static PowerMenuAccessibilityService getInstance() {
        return instance;
    }

    /**
     * Abre o menu de energia do Android usando performGlobalAction.
     * Retorna true se a ação foi executada com sucesso.
     */
    public boolean openPowerMenu() {
        Log.d(TAG, "Executando GLOBAL_ACTION_POWER_DIALOG");
        return performGlobalAction(GLOBAL_ACTION_POWER_DIALOG);
    }
}
