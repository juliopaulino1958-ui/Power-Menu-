package com.powermenuapp;

import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

/**
 * PowerMenuModule
 *
 * Módulo nativo React Native que expõe ao JavaScript as funções:
 *   - isAccessibilityEnabled(): verifica se o serviço está ativo
 *   - openAccessibilitySettings(): abre as configurações de acessibilidade
 *   - triggerPowerMenu(): aciona o menu de energia via AccessibilityService
 */
public class PowerMenuModule extends ReactContextBaseJavaModule {

    private static final String MODULE_NAME = "PowerMenuModule";

    public PowerMenuModule(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @NonNull
    @Override
    public String getName() {
        return MODULE_NAME;
    }

    /**
     * Verifica se o PowerMenuAccessibilityService está habilitado
     * nas configurações de acessibilidade do dispositivo.
     */
    @ReactMethod
    public void isAccessibilityEnabled(Promise promise) {
        try {
            Context context = getReactApplicationContext();
            String serviceName = context.getPackageName()
                    + "/" + PowerMenuAccessibilityService.class.getCanonicalName();

            String enabledServices = Settings.Secure.getString(
                    context.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            );

            boolean isEnabled = enabledServices != null
                    && enabledServices.contains(serviceName);

            promise.resolve(isEnabled);
        } catch (Exception e) {
            promise.reject("ERROR", "Erro ao verificar acessibilidade: " + e.getMessage());
        }
    }

    /**
     * Abre a tela de configurações de acessibilidade do Android.
     */
    @ReactMethod
    public void openAccessibilitySettings(Promise promise) {
        try {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getReactApplicationContext().startActivity(intent);
            promise.resolve(true);
        } catch (Exception e) {
            promise.reject("ERROR", "Erro ao abrir configurações: " + e.getMessage());
        }
    }

    /**
     * Aciona o menu de energia do Android via AccessibilityService.
     * Retorna erro se o serviço não estiver ativo.
     */
    @ReactMethod
    public void triggerPowerMenu(Promise promise) {
        try {
            PowerMenuAccessibilityService service =
                    PowerMenuAccessibilityService.getInstance();

            if (service == null) {
                promise.reject(
                    "SERVICE_NOT_ACTIVE",
                    "O serviço de acessibilidade não está ativo. " +
                    "Habilite-o nas configurações de acessibilidade."
                );
                return;
            }

            boolean success = service.openPowerMenu();
            if (success) {
                promise.resolve(true);
            } else {
                promise.reject("ACTION_FAILED", "Falha ao executar a ação do menu de energia.");
            }
        } catch (Exception e) {
            promise.reject("ERROR", "Erro inesperado: " + e.getMessage());
        }
    }
}
