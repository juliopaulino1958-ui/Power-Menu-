/**
 * index.js — Ponto de entrada do Power Menu App
 *
 * Registra o componente raiz no AppRegistry do React Native.
 * O nome "PowerMenuApp" deve corresponder ao retornado em
 * MainActivity.getMainComponentName().
 */

import { AppRegistry } from 'react-native';
import App from './App';
import { name as appName } from './app.json';

AppRegistry.registerComponent(appName, () => App);
