/**
 * App.tsx — Power Menu App
 *
 * Tela principal do aplicativo. Exibe um botão centralizado para abrir
 * o menu de energia do Android via AccessibilityService.
 *
 * Fluxo:
 * 1. Ao montar, verifica se o serviço de acessibilidade está habilitado.
 * 2. Se não estiver, exibe um aviso e um botão para abrir as configurações.
 * 3. Se estiver habilitado, o botão principal aciona o menu de energia.
 * 4. Ao voltar das configurações (AppState), re-verifica o status.
 */

import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
  AppState,
  AppStateStatus,
  ActivityIndicator,
  Platform,
  Alert,
} from 'react-native';
import {
  isAccessibilityEnabled,
  openAccessibilitySettings,
  triggerPowerMenu,
} from './src/PowerMenuNative';

type AppStatus = 'loading' | 'disabled' | 'enabled';

export default function App() {
  const [status, setStatus] = useState<AppStatus>('loading');
  const [isTriggering, setIsTriggering] = useState(false);

  // Verifica o status do serviço de acessibilidade
  const checkAccessibility = useCallback(async () => {
    try {
      const enabled = await isAccessibilityEnabled();
      setStatus(enabled ? 'enabled' : 'disabled');
    } catch {
      setStatus('disabled');
    }
  }, []);

  // Verifica ao montar o componente
  useEffect(() => {
    checkAccessibility();
  }, [checkAccessibility]);

  // Re-verifica quando o app volta ao primeiro plano
  // (útil após o usuário retornar das configurações de acessibilidade)
  useEffect(() => {
    const subscription = AppState.addEventListener(
      'change',
      (nextState: AppStateStatus) => {
        if (nextState === 'active') {
          checkAccessibility();
        }
      }
    );
    return () => subscription.remove();
  }, [checkAccessibility]);

  // Aciona o menu de energia
  const handlePowerMenu = async () => {
    if (isTriggering) return;
    setIsTriggering(true);
    try {
      await triggerPowerMenu();
    } catch (error: any) {
      Alert.alert(
        'Erro',
        error?.message || 'Não foi possível abrir o menu de energia.',
        [{ text: 'OK' }]
      );
    } finally {
      setIsTriggering(false);
    }
  };

  // Abre as configurações de acessibilidade
  const handleOpenSettings = async () => {
    try {
      await openAccessibilitySettings();
    } catch {
      Alert.alert(
        'Erro',
        'Não foi possível abrir as configurações de acessibilidade.',
        [{ text: 'OK' }]
      );
    }
  };

  // ── Tela de carregamento ──────────────────────────────────────────────────
  if (status === 'loading') {
    return (
      <View style={styles.container}>
        <StatusBar barStyle="light-content" backgroundColor="#1a1a2e" />
        <ActivityIndicator size="large" color="#e94560" />
        <Text style={styles.loadingText}>Verificando permissões...</Text>
      </View>
    );
  }

  // ── Tela de permissão não concedida ───────────────────────────────────────
  if (status === 'disabled') {
    return (
      <View style={styles.container}>
        <StatusBar barStyle="light-content" backgroundColor="#1a1a2e" />

        <View style={styles.iconContainer}>
          <Text style={styles.iconText}>⚠️</Text>
        </View>

        <Text style={styles.title}>Permissão Necessária</Text>

        <Text style={styles.description}>
          Para abrir o menu de energia, este aplicativo precisa que o serviço
          de acessibilidade <Text style={styles.bold}>Power Menu App</Text> esteja
          habilitado nas configurações do seu dispositivo.
        </Text>

        <View style={styles.instructionsBox}>
          <Text style={styles.instructionsTitle}>Como habilitar:</Text>
          <Text style={styles.instructionsStep}>
            1. Toque em "Abrir Configurações" abaixo
          </Text>
          <Text style={styles.instructionsStep}>
            2. Localize <Text style={styles.bold}>Power Menu App</Text> na lista
          </Text>
          <Text style={styles.instructionsStep}>
            3. Ative o serviço e confirme
          </Text>
          <Text style={styles.instructionsStep}>
            4. Volte ao aplicativo
          </Text>
        </View>

        <TouchableOpacity
          style={styles.settingsButton}
          onPress={handleOpenSettings}
          activeOpacity={0.8}>
          <Text style={styles.settingsButtonText}>
            Abrir Configurações de Acessibilidade
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.retryButton}
          onPress={checkAccessibility}
          activeOpacity={0.8}>
          <Text style={styles.retryButtonText}>Já habilitei — Verificar novamente</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // ── Tela principal (serviço habilitado) ───────────────────────────────────
  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#1a1a2e" />

      <View style={styles.statusBadge}>
        <View style={styles.statusDot} />
        <Text style={styles.statusText}>Serviço de acessibilidade ativo</Text>
      </View>

      <Text style={styles.title}>Menu de Energia</Text>

      <Text style={styles.description}>
        Pressione o botão abaixo para abrir o menu de energia do Android.
      </Text>

      <TouchableOpacity
        style={[styles.powerButton, isTriggering && styles.powerButtonDisabled]}
        onPress={handlePowerMenu}
        disabled={isTriggering}
        activeOpacity={0.8}>
        {isTriggering ? (
          <ActivityIndicator size="small" color="#ffffff" />
        ) : (
          <>
            <Text style={styles.powerButtonIcon}>⏻</Text>
            <Text style={styles.powerButtonText}>Abrir Menu de Energia</Text>
          </>
        )}
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.retryButton}
        onPress={handleOpenSettings}
        activeOpacity={0.8}>
        <Text style={styles.retryButtonText}>Configurações de Acessibilidade</Text>
      </TouchableOpacity>
    </View>
  );
}

// ── Estilos ────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a2e',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 28,
  },

  // Carregamento
  loadingText: {
    color: '#a0a0b0',
    fontSize: 16,
    marginTop: 16,
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System',
  },

  // Ícone de aviso
  iconContainer: {
    marginBottom: 20,
  },
  iconText: {
    fontSize: 56,
    textAlign: 'center',
  },

  // Título
  title: {
    color: '#ffffff',
    fontSize: 26,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 16,
    fontFamily: Platform.OS === 'android' ? 'sans-serif-medium' : 'System',
  },

  // Descrição
  description: {
    color: '#a0a0b0',
    fontSize: 15,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 24,
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System',
  },
  bold: {
    color: '#e94560',
    fontWeight: '700',
  },

  // Caixa de instruções
  instructionsBox: {
    backgroundColor: '#16213e',
    borderRadius: 12,
    padding: 18,
    width: '100%',
    marginBottom: 28,
    borderLeftWidth: 3,
    borderLeftColor: '#e94560',
  },
  instructionsTitle: {
    color: '#e94560',
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 10,
    fontFamily: Platform.OS === 'android' ? 'sans-serif-medium' : 'System',
  },
  instructionsStep: {
    color: '#c0c0d0',
    fontSize: 14,
    lineHeight: 22,
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System',
  },

  // Badge de status
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#0f3460',
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 6,
    marginBottom: 32,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#4ade80',
    marginRight: 8,
  },
  statusText: {
    color: '#4ade80',
    fontSize: 13,
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System',
  },

  // Botão principal — Menu de Energia
  powerButton: {
    backgroundColor: '#e94560',
    borderRadius: 16,
    paddingVertical: 20,
    paddingHorizontal: 40,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    marginBottom: 16,
    elevation: 6,
    shadowColor: '#e94560',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    minHeight: 72,
  },
  powerButtonDisabled: {
    backgroundColor: '#7a2030',
    elevation: 2,
  },
  powerButtonIcon: {
    color: '#ffffff',
    fontSize: 28,
    marginBottom: 4,
  },
  powerButtonText: {
    color: '#ffffff',
    fontSize: 17,
    fontWeight: '700',
    fontFamily: Platform.OS === 'android' ? 'sans-serif-medium' : 'System',
  },

  // Botão de configurações (primário)
  settingsButton: {
    backgroundColor: '#0f3460',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
    width: '100%',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#1a4a8a',
  },
  settingsButtonText: {
    color: '#ffffff',
    fontSize: 15,
    fontWeight: '600',
    fontFamily: Platform.OS === 'android' ? 'sans-serif-medium' : 'System',
  },

  // Botão secundário
  retryButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  retryButtonText: {
    color: '#6070a0',
    fontSize: 14,
    fontFamily: Platform.OS === 'android' ? 'sans-serif' : 'System',
    textDecorationLine: 'underline',
  },
});
